# Back-End-Developer-Capstone
META Back-End Developer Course Capstone Project implemented by Siarhei Sushynski

Please, see Readme.txt file for review process in Week4 of the course.

